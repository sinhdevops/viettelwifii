# BOARDROOM — ĐIỀU PHỐI ĐỘI AGENT VIETTELUP

**Trạng thái khởi tạo:** đã chuẩn bị cấu hình và phân công agent; chưa chạy đội triển khai, chưa clone hoặc code website. Các task bên dưới là kế hoạch, không phải bằng chứng đã hoàn thành.

Đây là bảng điều phối local của repository. Mục tiêu và 171 route nằm trong `MASTER_PROMPT_VIETTELUP.md`; tài liệu này sở hữu phân công, quyền sửa file, phụ thuộc và trạng thái thực thi. File `.codex/agents/*.toml` chứa chỉ dẫn chuyên môn. Yêu cầu mới nhất của người dùng quyết định phạm vi đang được phép thực hiện.

## 1. Khởi động và điều phối

- Chat chính đảm nhiệm `vt_lead`; đọc `.codex/agents/vt_lead.toml`, master prompt và tài liệu này. Không spawn thêm một Lead rồi tạo hai cấp cùng điều phối.
- Khi người dùng yêu cầu triển khai, Lead chủ động gọi các chuyên môn cần thiết bằng công cụ subagent. Tối đa **5 subagent đang mở**, không tính chat chính; giới hạn thực tế thấp hơn thì dùng mức thấp hơn. Không cần mở cả 9 chuyên môn cùng lúc.
- Worker không spawn agent con và không tạo chat mới. Lead thu kết quả, lưu checkpoint, đóng worker đã xong để trả slot; mở lại khi cần tiếp tục cùng ngữ cảnh.
- Cấu hình project ở `.codex/config.toml`; profile ở `.codex/agents/`. Không ghi đè model, provider, quyền, tài khoản hay cấu hình global. Các profile kế thừa lựa chọn của phiên chính.
- Nếu phiên đang mở chưa nhận tên custom agent, thử ở phiên mới của cùng project đã được tin cậy. Khi công cụ chỉ có worker chuẩn, Lead đọc file profile và truyền nguyên `developer_instructions` cùng nhiệm vụ vào worker đó. Nếu không có công cụ subagent, báo giới hạn và thực hiện tuần tự trong phạm vi đã giao; không giả báo chạy song song.
- Yêu cầu chuẩn bị/cập nhật agent hoặc tài liệu chỉ cho phép làm phần cấu hình đó. Không tự khởi động việc làm website từ một task chuẩn bị.

## 2. Danh sách chuyên môn

| Tên gọi chính xác       | Vai trò                        | Đầu ra chính                                                                    |
| ----------------------- | ------------------------------ | ------------------------------------------------------------------------------- |
| `vt_lead`               | Điều phối, kiến trúc, tích hợp | Manifest, hợp đồng dùng chung, route/layout, ghép code, Boardroom và nghiệm thu |
| `vt_source_data`        | Nguồn và nội dung              | Dữ liệu có kiểu của 171 route, raw evidence, mapping CTA và ngoại lệ            |
| `vt_assets_reference`   | Asset và baseline tham chiếu   | File local, registry media/font, screenshot và mô tả giao diện/hành vi          |
| `vt_shared_home`        | UI chung và trang chủ          | Token, layout, menu, component chung, template trang chủ                        |
| `vt_packages`           | Gói cước di động               | Template/biến thể cho 116 route, gồm 15 route trả sau                           |
| `vt_internet`           | Internet                       | Template/biến thể cho 18 route Internet                                         |
| `vt_news`               | Tin tức                        | Listing và template cho 35 bài viết                                             |
| `vt_forms_integrations` | Form, API lead, tracking       | Hợp đồng CTA/form, popup, server validate, tích hợp và kiểm tra mock/sandbox    |
| `vt_seo_performance`    | SEO và hiệu năng               | Metadata/JSON-LD helper, robots/sitemap, kiểm tra HTML và báo cáo hiệu năng     |
| `vt_qa`                 | QA độc lập                     | Test, screenshot bản local, lỗi có cách tái hiện và kiểm tra hồi quy            |

## 3. Hợp đồng làm việc chung

### Đầu vào bắt buộc cho mỗi task

Lead phải giao đủ: `task_id`, mục tiêu, route/nhóm hoặc mẫu trang, nguồn được đọc, file/glob được sửa, giao diện dữ liệu/component cần tuân thủ, phụ thuộc đã sẵn, kiểm tra áp dụng và đầu ra mong đợi. Không giao kiểu “làm toàn bộ frontend” cho nhiều worker.

Worker đọc `AGENTS.md`, phần master prompt liên quan, hợp đồng của task và ma trận này. Chỉ đọc sâu phụ lục/nguồn cần cho nhiệm vụ; tránh nạp toàn bộ crawl vào ngữ cảnh. Trước code Next.js phải đọc hướng dẫn cục bộ liên quan trong `node_modules/next/dist/docs/`.

### Quyền sửa và tài nguyên chung

- Một file chỉ có một owner được quyền ghi tại một thời điểm. Thông báo sửa file không thay thế việc Lead cấp quyền.
- Khi cần sửa ngoài phạm vi, gửi đường dẫn, lý do và patch/đề nghị cho owner. Lead có thể chuyển quyền một file khi owner cũ đã dừng và bàn giao; ghi quyết định vào checkpoint.
- Worker không sửa Boardroom, schema, dependency hoặc file của nhóm khác để tự tháo vướng. Không revert thay đổi không phải của mình.
- Các test cũng có owner. Nhóm sản phẩm tự kiểm tra phần mình và gửi ca kiểm tra cho QA; không đồng thời cùng ghi `tests/**`.
- Lead quản lý dev server/cổng và các lệnh kiểm tra toàn dự án. Worker chạy kiểm tra cục bộ phù hợp; không tự khởi động nhiều server hoặc cùng chạy production build.
- Mỗi phiên browser có tab/context được giao rõ ràng. Hai agent không cùng điều khiển một tab. Asset/reference và QA lưu screenshot ở thư mục riêng.
- Báo cáo và raw evidence ghi vào namespace riêng; file tổng hợp chỉ có một người ghi.

### Tính đúng và phạm vi

Giữ nguyên 171 route, chữ hoa/thường và route lồng. Không mở rộng từ link trên nguồn. Gói trùng mã ở route thường và trả sau phải có định danh phân biệt. Source/Data xác minh nội dung, UI không tự viết số liệu để lấp chỗ thiếu.

Nội dung/asset công khai chỉ được tái sử dụng trong quyền người dùng đã có. Không vượt đăng nhập hoặc giới hạn truy cập; không mang script/tracking của website nguồn vào bản mới. Giữ secret ở server và không đưa PII vào log/analytics.

Không tự deploy, push, mở index, bật `SITE_LIVE`, gọi điện, gửi SMS/lead/tin Telegram thật hoặc kích hoạt quảng cáo. Thiếu cấu hình tích hợp thật không chặn việc độc lập và kiểm tra mock có ghi rõ.

### Báo cáo bàn giao của worker

Lưu tại `reports/agent-handoffs/<agent>/<task_id>.md`; chỉ owner của namespace đó ghi. Nội dung gọn theo mẫu:

```text
task_id:
status: ready_for_review | needs_changes | blocked
routes_or_scope:
changed_files:
exports_or_contract:
checks_run_and_results:
evidence_paths:
known_gaps_or_blockers:
next_input_needed:
```

Tách rõ kiểm tra mock, tích hợp thật, kiểm tra bằng trình duyệt và phần chưa chạy. Không ghi secret/PII. Trả bản tóm tắt cho Lead kèm đường dẫn báo cáo; không đổ toàn bộ raw log vào chat chính. `ready_for_review` là đã tự kiểm và chờ kiểm tra độc lập, chưa phải nghiệm thu.

## 4. Ma trận quyền sửa mặc định

Các thư mục chưa có là nơi dự kiến tạo khi triển khai; bảng này không khẳng định code đã tồn tại. Quyền thực tế của mỗi task có thể hẹp hơn. Tài liệu quyền sửa không thay thế sandbox hoặc quyền công cụ.

| Owner                   | Phạm vi ghi                                                                                                                                                                                                                                                                                                                                                                                        |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `vt_lead`               | `data/approved-routes.json`; type/schema dùng chung; `src/lib/content-schema.ts`, `src/lib/site-data.ts`, `src/lib/scope.ts`; route page và root layout trong `src/app/` trừ các file đã giao ở hàng khác; `src/components/site/page-renderer.tsx`; cấu hình gốc, dependency, script phạm vi; `AGENTS.md`, tài liệu kế hoạch, Boardroom; `reports/clone-checklist.csv` và `reports/integration/**` |
| `vt_source_data`        | `data/sources/**`, `data/content/**`, `data/pages.json`, `reference-clone/raw/**`, `scripts/content/**`, `reports/source-audit/**`                                                                                                                                                                                                                                                                 |
| `vt_assets_reference`   | `public/assets/viettelup/**`, `data/asset-registry.json`, `reference-clone/baseline/**`, `reports/reference/**`                                                                                                                                                                                                                                                                                    |
| `vt_shared_home`        | `src/components/layout/**`, `src/components/shared/**`, `src/components/ui/**`, `src/features/home/**`, `src/app/globals.css`                                                                                                                                                                                                                                                                      |
| `vt_packages`           | `src/features/packages/**`                                                                                                                                                                                                                                                                                                                                                                         |
| `vt_internet`           | `src/features/internet/**`                                                                                                                                                                                                                                                                                                                                                                         |
| `vt_news`               | `src/features/news/**`                                                                                                                                                                                                                                                                                                                                                                             |
| `vt_forms_integrations` | `src/components/leads/**`, `src/features/leads/**`, `src/components/site/floating-contact.tsx`, `src/app/api/leads/**`, `src/lib/lead-schema.ts`, `src/lib/analytics.ts`, `.env.example`                                                                                                                                                                                                           |
| `vt_seo_performance`    | `src/features/seo/**`, `src/app/robots.ts`, `src/app/sitemap.ts`, `reports/seo-performance/**`                                                                                                                                                                                                                                                                                                     |
| `vt_qa`                 | `tests/**`, `reports/qa/**`                                                                                                                                                                                                                                                                                                                                                                        |

Mỗi agent còn được ghi `reports/agent-handoffs/<tên-agent>/**`. Profile/config agent chỉ thay khi task hiện hành cho phép cấu hình đội, không phải vì worker muốn tăng quyền. Các đường dẫn mới chưa có owner mặc định thuộc Lead cho đến khi được giao.

## 5. Hợp đồng cần chốt trước khi nhân rộng

Lead dùng mẫu nguồn và baseline đầu tiên để ghi hợp đồng vào `docs/IMPLEMENTATION_CONTRACT.md` khi bắt đầu triển khai. Tệp này chưa được tạo ở bước chuẩn bị, vì schema chi tiết phải dựa trên nguồn đã khảo sát.

Hợp đồng phải xác định:

1. Path chuẩn, kind, product ID phân biệt loại thuê bao, đơn vị giá/chu kỳ/quyền lợi và trường nguồn; schema mở rộng cho bài viết/bảng/section thực tế.
2. Export/props của layout, card, template trang và component tương tác dùng chung. Frontend không phụ thuộc đường dẫn chưa được owner cam kết bàn giao.
3. Mapping CTA và props form; cách server tra đúng sản phẩm tin cậy trên cả trang chi tiết lẫn listing.
4. Registry asset và quy tắc đặt tên; nguồn nội dung chỉ có một writer, không để các agent UI ghi `data/pages.json`.
5. Input metadata/JSON-LD, domain cấu hình và điều kiện index/sitemap.
6. Cơ chế preview local/test cho draft và mốc đổi sang ready. QA phải có cách nhìn trang đang hoàn thiện mà không nới guard production, thêm route kinh doanh ngoài allowlist hoặc index nhầm.

Chốt phiên bản hợp đồng trước khi các owner dùng chung. Thay đổi sau đó phải nêu consumer bị ảnh hưởng và việc tích hợp cần làm. Không định nghĩa schema hư cấu chỉ để giao việc sớm.

## 6. Nhịp chạy song song

**Đợt chuẩn bị:** Lead kiểm tra repo và tạo manifest chính xác từ phụ lục. Source/Data khảo sát nội dung mẫu; Assets khảo sát visual/media mẫu. Forms có thể rà tích hợp sẵn có; QA chuẩn bị matrix. Chỉ crawl các path đã được duyệt và phân công.

**Đợt dựng nền:** khi mẫu nguồn đủ, Lead chốt hợp đồng. Source/Data tiếp tục toàn bộ theo lô và Assets bàn giao asset tương ứng. Shared/Home dựng thành phần dùng chung; Forms làm hợp đồng và tích hợp; SEO chuẩn bị helper. Chọn tối đa năm worker có đầu vào sẵn.

**Đợt các nhóm trang:** Packages, Internet, News dựng mẫu và biến thể song song dựa trên hợp đồng, dữ liệu và baseline đã sẵn. Shared/Home hoàn thiện phần chung; Source hoặc Assets tiếp tục các lô còn thiếu khi có slot. Không bắt các nhóm chờ toàn bộ crawl hoặc toàn bộ trang chủ hoàn thiện nếu hợp đồng cần dùng đã ổn định.

**Đợt kiểm tra cuốn chiếu:** Lead tích hợp từng lô; QA kiểm tra lô đó trong khi nhóm khác tiếp tục. Lỗi trả đúng owner. SEO kiểm tra metadata/HTML và nút thắt sau tích hợp.

**Đợt chốt:** Lead chạy kiểm tra toàn site một cách có kiểm soát; QA xác nhận route/luồng và các lỗi đã sửa; Source/Data cập nhật trạng thái nội dung theo điều kiện đã chốt. Thiếu nguồn hoặc cấu hình thì ghi ngoại lệ cụ thể, không gọi toàn bộ đã hoàn thành.

Nếu task bị chặn, giữ bằng chứng và chuyển sang task độc lập. Không duy trì worker rảnh chỉ để chiếm slot; không chờ tất cả worker xong mới nhận một lô đã sử dụng được.

## 7. Bảng nhiệm vụ ban đầu

Trạng thái bảng: `queued` → `in_progress` → `ready_for_review` → `verified`. Nhánh lỗi dùng `needs_changes`; thiếu đầu vào dùng `blocked` kèm lý do. Chỉ Lead ghi bảng, QA cung cấp bằng chứng kiểm tra. Trạng thái nội dung ứng dụng `draft`/`ready` là lớp khác.

Ký hiệu “lô đầu” nghĩa là phần dữ liệu/asset cần cho mẫu đã được bàn giao, không phải toàn bộ task lớn đã hoàn thành. Lead tách task theo nhóm/lô khi thực thi để theo dõi được tiến độ thực.

| Task ID     | Owner                   | Công việc                                                | Phụ thuộc/điều kiện bắt đầu                            | Trạng thái | Bằng chứng |
| ----------- | ----------------------- | -------------------------------------------------------- | ------------------------------------------------------ | ---------- | ---------- |
| PRE-01      | `vt_lead`               | Preflight, manifest đúng 171 path, đối chiếu tài liệu cũ | Người dùng yêu cầu bắt đầu triển khai                  | queued     | —          |
| REF-01      | `vt_source_data`        | Nội dung mẫu năm nhóm và biến thể trả sau                | PRE-01                                                 | queued     | —          |
| REF-02      | `vt_assets_reference`   | Baseline và asset mẫu ở ba kích thước                    | PRE-01                                                 | queued     | —          |
| CONTRACT-01 | `vt_lead`               | Hợp đồng dữ liệu/component/CTA/preview                   | Mẫu đủ từ REF-01 và REF-02                             | queued     | —          |
| DATA-01     | `vt_source_data`        | Dữ liệu 171 route, giao từng lô và ghi ngoại lệ          | CONTRACT-01                                            | queued     | —          |
| ASSET-01    | `vt_assets_reference`   | Asset local, registry và biến thể còn lại                | CONTRACT-01; danh sách media theo lô                   | queued     | —          |
| UI-01       | `vt_shared_home`        | UI chung và trang chủ, export sớm component              | CONTRACT-01; nguồn/asset lô trang chủ                  | queued     | —          |
| FORM-01     | `vt_forms_integrations` | Hợp đồng form, API lead và tracking                      | Rà soát sớm; sửa code sau CONTRACT-01                  | queued     | —          |
| PKG-01      | `vt_packages`           | Mẫu/biến thể và 116 route gói cước                       | CONTRACT-01; nguồn/asset/component cần dùng của lô đầu | queued     | —          |
| NET-01      | `vt_internet`           | Mẫu/biến thể và 18 route Internet                        | CONTRACT-01; nguồn/asset/component cần dùng của lô đầu | queued     | —          |
| NEWS-01     | `vt_news`               | Listing và 35 bài viết                                   | CONTRACT-01; nguồn/asset/component cần dùng của lô đầu | queued     | —          |
| SEO-01      | `vt_seo_performance`    | Helper metadata, robots/sitemap, kiểm tra HTML           | CONTRACT-01; kiểm tra trên lô đã tích hợp              | queued     | —          |
| QA-01       | `vt_qa`                 | Matrix, kiểm tra các lô và hồi quy                       | Matrix sau PRE-01; browser check khi lô local đã chạy  | queued     | —          |
| FINAL-01    | `vt_lead`               | Kiểm tra tổng và bàn giao có bằng chứng                  | Các lô và lỗi cần sửa đã xử lý/ghi chặn rõ             | queued     | —          |

## 8. Nghiệm thu và checkpoint

Mỗi owner tự kiểm phần mình; QA kiểm độc lập chức năng và giao diện theo lô. Chỉ Lead chuyển task sang verified sau khi xem thay đổi, kiểm tra và báo cáo QA áp dụng.

Các kiểm tra tổng theo master prompt: scope đúng; typecheck, lint và test liên quan; smoke 171 route với định danh đúng và 404; template/biến thể ở 390/768/1440px; interaction và form; asset/console; metadata/sitemap/noindex; production build ở mốc cuối. Lighthouse chỉ khi phạm vi yêu cầu. Không báo kiểm tra chưa chạy là đạt.

Checkpoint do Lead ghi tại phần cuối tài liệu này, gồm: task đang chạy và agent ID, file đang giữ quyền sửa, hợp đồng hiện hành, lô/route đã nghiệm thu, lỗi hoặc chặn, trạng thái server/browser, lệnh kiểm tra gần nhất và bước tiếp theo. Không lưu secret/PII hoặc toàn bộ raw log.

### Checkpoint hiện tại

- Đã chuẩn bị: 10 profile chuyên môn, config tối đa 5 subagent, master prompt và quy tắc điều phối.
- Website: vẫn là starter; chưa tạo manifest/content thật hoặc triển khai giao diện trong bước cấu hình đội.
- Task thực thi website: chưa khởi động; không có worker website đang được giao việc từ bảng này.
- Bước kế tiếp khi người dùng yêu cầu chạy: chat chính nhận vai trò `vt_lead`, làm PRE-01 rồi phân việc độc lập theo các đợt.

## 9. Tham chiếu cấu hình

Định dạng custom agent và giới hạn phiên theo [OpenAI Docs — Subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents). Cấu hình project chỉ được nạp khi project được tin cậy theo [Config basics](https://learn.chatgpt.com/docs/config-file/config-basic). Việc có file cấu hình không chứng minh đội agent đã được chạy hoặc website đã được kiểm tra.

# ViettelUp Next.js Core — clone-first migration kit

**Bộ source starter và master plan**, không phải sản phẩm đã clone xong. Thiết kế quy trình: **True Web Clone → HTML chuẩn → đóng băng baseline → port từng template sang Next.js → gắn core SEO/Ads/Form → QA**.

Đọc trước: [MASTER_PLAN](docs/MASTER_PLAN.md), [Sơ đồ và cấu trúc](docs/ARCHITECTURE.md), [Phạm vi 171 URL](docs/ROUTE_SCOPE.md).

Đội 10 agent đã được chuẩn bị trong `.codex/agents/`, kế thừa model và quyền của phiên chính, tối đa 5 subagent đang mở. Dùng [hướng dẫn khởi động](docs/START_AGENTS.md), [master prompt](docs/MASTER_PROMPT_VIETTELUP.md) và [Boardroom](docs/BOARDROOM.md) cho lần triển khai tiếp theo. Chat chính làm Lead; bộ agent chưa tự khởi động làm website.

## Điều đang bị chặn

Danh sách **đủ 171 path** đã có trong phụ lục `docs/MASTER_PROMPT_VIETTELUP.md`, khớp phạm vi 1/116/36/18. `data/approved-routes.json` và `data/pages.json` vẫn chưa được tạo ở bước chuẩn bị agent. Khi bắt đầu triển khai, Lead tạo manifest từ chính phụ lục này, chạy kiểm tra phạm vi rồi phối hợp thu thập nội dung. **Không đổi tên example thành dữ liệu thật.**

Không cần yêu cầu người dùng gửi lại sitemap đã được thay bằng danh sách đầy đủ trong master prompt. Build production **cố ý dừng** nếu thiếu/khác tập route được duyệt; có manifest không đồng nghĩa đã có đủ nội dung được xác minh.

## Khởi chạy sau khi cài dependency

```bash
corepack enable
pnpm install
cp .env.example .env.local
pnpm dev
```

Trong `.env.local`, `SITE_LIVE=false` là mặc định. Trang chủ hiện thông báo đang chuẩn bị, không xuất bản bản clone giả. Khi đủ route và content: chạy `pnpm routes:check`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm build`, `pnpm test:e2e`.

Lập bảng audit đúng 171 URL sau khi nhận manifest: `pnpm routes:audit`. Kết quả là `reports/clone-checklist.csv`, dùng để đánh dấu baseline/asset/interactions/port/review từng trang.

Để triển khai production, cần `NEXT_PUBLIC_SITE_URL` domain thật, đủ dữ liệu, quyền tài nguyên, thông tin liên hệ, Telegram và anti-spam đã cấu hình, kiểm tra riêng việc bảo vệ dữ liệu, rồi mới chuyển `SITE_LIVE=true`. Không chạy `output: "export"` vì form Telegram cần server.

## Nhập nội dung route

`data/approved-routes.json` chấp nhận `{"routes": ["/", "/tin-tuc", ...]}` hoặc array path. **Bắt buộc đủ đúng 171 URL** theo tỉ lệ 1/116/36/18.

`data/pages.json` là object với keys chính xác bằng URL; dữ liệu page gồm:

- `status`: `draft` hoặc `ready`.
- `kind`: `home`, `package`, `internet`, `news-list`, `news-article`.
- `title`, `description`, `heading`, `intro` tùy chọn.
- `sections`: `text`, `cards`, `faq`; mở rộng template khi port HTML thật.

Chỉ page `ready` trong allowlist mới có route/sitemap; page khác trả 404 (trừ trang chủ scaffold). Không trích toàn bộ các link ngoài vào tập URL được phép.

## Tích hợp đã sẵn khung

- TypeScript, Next.js 16.4, App Router, Tailwind CSS 4, ESLint flat config, Prettier, Husky, lint-staged, Vitest, Playwright.
- shadcn-style button/dialog, CVA/clsx/tailwind-merge, Lucide, Sonner.
- React Hook Form + Zod; form gắn `itemId`, Zod server revalidate, Cloudflare Turnstile server verify, Telegram Bot API server-only.
- Floating phone/Zalo; `dataLayer` events cho GTM (`contact_phone_click`, `contact_zalo_click`, `lead_submit_success`), không chứa PII.
- SEO metadata/canonical, robots noindex trước launch, sitemap từ page thật.

Shadcn component khác **chỉ thêm khi clone archetype cần**: `pnpm dlx shadcn@latest add badge breadcrumb calendar checkbox dropdown-menu input select sidebar skeleton spinner tooltip popover tabs accordion table pagination command switch radio-group alert-dialog`. Carousel của shadcn dựa trên Embla; chỉ cài Swiper nếu reference thật sự cần hiệu ứng Swiper.

## Chưa làm / không được khẳng định đã làm

- **Chưa clone toàn bộ trang**: danh sách 171 URL đã có; manifest machine-readable, HTML/asset baseline và dữ liệu được duyệt còn cần được tạo khi triển khai.
- Chưa kiểm tra visual diff với website tham chiếu; Playwright hiện chỉ có smoke framework.
- Form chưa có thông tin bot thật, hệ thống rate limit distributed, hàng đợi lưu lead dự phòng; nếu lượng Ads lớn cần bổ sung trước launch.
- SEO và CWV chỉ có nền kỹ thuật, chưa thể đánh giá kết quả khi chưa có trang thật và deployment thật.

## Security

Không commit `.env.local`, bot token, chat ID, lead cá nhân, hoặc clone HTML chứa key bên thứ ba. Telegram credentials chỉ ở server. Chỉ kích hoạt tracking theo cấu hình consent phù hợp. Với website gốc bên thứ ba, xác minh quyền sử dụng logo, hình ảnh và nội dung trước khi public.
